function makeheader(){
    let header = document.querySelector("header")

    header.innerHTML = ``
}

window.addEventListener("load", makeheader)